import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

void main() => runApp(const OmniAiApp());

class OmniAiApp extends StatelessWidget {
  const OmniAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Omni AI', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
    home: const ChatPage(),
  );
}

class ChatMessage {
  ChatMessage(this.role, this.content);
  final String role;
  final String content;
  Map<String, dynamic> toJson() => {'role': role, 'content': content};
}

class ApiSettings {
  String baseUrl;
  String apiKey;
  String model;
  ApiSettings({this.baseUrl = '', this.apiKey = '', this.model = ''});
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _messages = <ChatMessage>[];
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  ApiSettings _settings = ApiSettings();
  List<String> _models = [];
  bool _busy = false;
  bool _listening = false;
  String? _error;

  @override
  void initState() { super.initState(); _loadSettings(); }
  @override
  void dispose() { _input.dispose(); _scroll.dispose(); super.dispose(); }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    setState(() => _settings = ApiSettings(
      baseUrl: p.getString('baseUrl') ?? '',
      apiKey: p.getString('apiKey') ?? '', model: p.getString('model') ?? '',
    ));
    await _fetchModels(silent: true);
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('baseUrl', _settings.baseUrl);
    await p.setString('apiKey', _settings.apiKey);
    await p.setString('model', _settings.model);
  }

  Uri _endpoint(String path) {
    var base = _settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (!base.endsWith('/v1')) base = '$base/v1';
    return Uri.parse('$base$path');
  }
  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_settings.apiKey.trim().isNotEmpty) 'Authorization': 'Bearer ${_settings.apiKey.trim()}',
  };

  Future<void> _fetchModels({bool silent = false}) async {
    try {
      final r = await http.get(_endpoint('/models'), headers: _headers).timeout(const Duration(seconds: 15));
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception('HTTP ${r.statusCode}: ${r.body}');
      final body = jsonDecode(r.body) as Map<String, dynamic>;
      final data = (body['data'] as List? ?? []).cast<Map<String, dynamic>>();
      final names = data.map((e) => '${e['id']}').toList();
      if (!mounted) return;
      setState(() { _models = names; if (_settings.model.isEmpty && names.isNotEmpty) _settings.model = names.first; _error = null; });
      await _saveSettings();
    } catch (e) { if (mounted && !silent) setState(() => _error = 'Не удалось получить модели: $e'); }
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _busy) return;
    if (_settings.model.isEmpty) { setState(() => _error = 'Сначала настройте сервер и выберите модель.'); return; }
    setState(() { _messages.add(ChatMessage('user', text)); _input.clear(); _busy = true; _error = null; });
    _jumpToBottom();
    try {
      final r = await http.post(_endpoint('/chat/completions'), headers: _headers,
        body: jsonEncode({'model': _settings.model, 'messages': _messages.map((m) => m.toJson()).toList(), 'stream': false}),
      ).timeout(const Duration(minutes: 3));
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception('HTTP ${r.statusCode}: ${r.body}');
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      final choices = data['choices'] as List? ?? [];
      final content = choices.isNotEmpty ? (choices.first['message']?['content']?.toString() ?? '') : '';
      setState(() => _messages.add(ChatMessage('assistant', content.isEmpty ? '(Пустой ответ модели)' : content)));
    } catch (e) { setState(() => _error = 'Ошибка запроса: $e'); }
    finally { if (mounted) setState(() => _busy = false); _jumpToBottom(); }
  }

  void _jumpToBottom() { WidgetsBinding.instance.addPostFrameCallback((_) { if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut); }); }

  Future<void> _voiceInput() async {
    if (_listening) { await _speech.stop(); setState(() => _listening = false); return; }
    final available = await _speech.initialize(onStatus: (s) { if (s == 'done' && mounted) setState(() => _listening = false); }, onError: (e) { if (mounted) setState(() { _listening = false; _error = 'Голосовой ввод: ${e.errorMsg}'; }); });
    if (!available) { setState(() => _error = 'Распознавание речи недоступно на этом устройстве.'); return; }
    setState(() => _listening = true);
    await _speech.listen(onResult: (result) { if (mounted) setState(() => _input.text = result.recognizedWords); });
  }

  Future<void> _speak(String text) async { try { await _tts.stop(); await _tts.speak(text); } catch (_) {} }

  Future<void> _openSettings() async {
    final base = TextEditingController(text: _settings.baseUrl);
    final key = TextEditingController(text: _settings.apiKey);
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Подключение к AI-серверу'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: base, decoration: const InputDecoration(labelText: 'Base URL', hintText: 'https://ваш-защищённый-сервер/v1'), keyboardType: TextInputType.url),
        const SizedBox(height: 12), TextField(controller: key, decoration: const InputDecoration(labelText: 'API key (если нужен)'), obscureText: true),
        const SizedBox(height: 12), const Text('Нужен сервер с OpenAI-совместимым API, например Open WebUI, Ollama через совместимый шлюз или провайдер API. Для телефона localhost указывает на сам телефон, а не на компьютер.', style: TextStyle(fontSize: 12)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')), FilledButton(onPressed: () { setState(() { _settings.baseUrl = base.text.trim(); _settings.apiKey = key.text.trim(); }); Navigator.pop(ctx); }, child: const Text('Сохранить'))],
    ));
    await _saveSettings(); await _fetchModels();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Omni AI'), actions: [
      if (_models.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: DropdownButton<String>(value: _models.contains(_settings.model) ? _settings.model : null, hint: const Text('Модель'), underline: const SizedBox(), items: _models.map((m) => DropdownMenuItem(value: m, child: Text(m, overflow: TextOverflow.ellipsis))).toList(), onChanged: (v) async { if (v != null) setState(() => _settings.model = v); await _saveSettings(); })),
      IconButton(tooltip: 'Обновить модели', onPressed: _fetchModels, icon: const Icon(Icons.refresh)), IconButton(tooltip: 'Настройки', onPressed: _openSettings, icon: const Icon(Icons.settings)),
    ]),
    body: Column(children: [
      if (_error != null) Material(color: Theme.of(context).colorScheme.errorContainer, child: Padding(padding: const EdgeInsets.all(8), child: Row(children: [Expanded(child: Text(_error!)), IconButton(onPressed: () => setState(() => _error = null), icon: const Icon(Icons.close))]))),
      Expanded(child: _messages.isEmpty ? const Center(child: Padding(padding: EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.forum_outlined, size: 56), SizedBox(height: 16), Text('Ваш универсальный AI-чат', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w600)), SizedBox(height: 8), Text('Откройте настройки и укажите адрес OpenAI-совместимого сервера. Выбор моделей появится после подключения.', textAlign: TextAlign.center)]))) : ListView.builder(controller: _scroll, padding: const EdgeInsets.all(12), itemCount: _messages.length + (_busy ? 1 : 0), itemBuilder: (context, i) {
        if (_busy && i == _messages.length) return const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()));
        final m = _messages[i]; final user = m.role == 'user';
        return Align(alignment: user ? Alignment.centerRight : Alignment.centerLeft, child: ConstrainedBox(constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .86), child: Card(color: user ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest, child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SelectableText(m.content), if (!user) Align(alignment: Alignment.centerRight, child: IconButton(tooltip: 'Прочитать вслух', visualDensity: VisualDensity.compact, onPressed: () => _speak(m.content), icon: const Icon(Icons.volume_up, size: 18)))])))));
      })),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(10, 6, 10, 10), child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        IconButton(tooltip: _listening ? 'Остановить запись' : 'Голосовой ввод', onPressed: _voiceInput, icon: Icon(_listening ? Icons.mic : Icons.mic_none)),
        Expanded(child: TextField(controller: _input, minLines: 1, maxLines: 6, textInputAction: TextInputAction.newline, decoration: const InputDecoration(hintText: 'Напишите сообщение…', border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12)), onSubmitted: (_) => _send())),
        const SizedBox(width: 6), IconButton.filled(tooltip: 'Отправить', onPressed: _busy ? null : _send, icon: const Icon(Icons.send)),
      ]))),
    ]),
  );
}
