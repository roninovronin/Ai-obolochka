﻿$ErrorActionPreference = 'Stop'

Write-Host '=== AI-obolochka Android APK build ===' -ForegroundColor Cyan

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Flutter не найден. Установите Flutter SDK и добавьте flutter\bin в PATH: https://docs.flutter.dev/get-started/install/windows/mobile'
}

flutter doctor
if ($LASTEXITCODE -ne 0) { throw 'flutter doctor сообщил об ошибках. Сначала исправьте Android toolchain.' }

# Keep the authored app and dependency manifest safe while Flutter generates platform files.
$appSource = Get-Content (Join-Path $PWD 'lib\main.dart') -Raw
$pubspec = Get-Content (Join-Path $PWD 'pubspec.yaml') -Raw
flutter create --platforms=android --org ru.aiobolochka .
if ($LASTEXITCODE -ne 0) { throw 'Не удалось сгенерировать Android-проект.' }
Set-Content -Path (Join-Path $PWD 'lib\main.dart') -Value $appSource -Encoding UTF8
Set-Content -Path (Join-Path $PWD 'pubspec.yaml') -Value $pubspec -Encoding UTF8

# Add internet and microphone permissions without globally enabling cleartext HTTP.
$manifest = Join-Path $PWD 'android\app\src\main\AndroidManifest.xml'
if (-not (Test-Path $manifest)) { throw "Не найден AndroidManifest.xml: $manifest" }
$xml = Get-Content $manifest -Raw
$permissions = @()
if ($xml -notmatch 'android.permission.INTERNET') { $permissions += '    <uses-permission android:name="android.permission.INTERNET" />' }
if ($xml -notmatch 'android.permission.RECORD_AUDIO') { $permissions += '    <uses-permission android:name="android.permission.RECORD_AUDIO" />' }
if ($permissions.Count -gt 0) {
  # Insert permissions immediately after the opening <manifest ...> tag,
  # not after the XML declaration.
  $manifestTag = [regex]::Match($xml, '<manifest\b[^>]*>')
  if (-not $manifestTag.Success) { throw 'Не удалось найти открывающий тег <manifest> в AndroidManifest.xml.' }
  $insertAt = $manifestTag.Index + $manifestTag.Length
  $xml = $xml.Insert($insertAt, "`r`n" + ($permissions -join "`r`n"))
  Set-Content -Path $manifest -Value $xml -Encoding UTF8
}

flutter pub get
if ($LASTEXITCODE -ne 0) { throw 'flutter pub get завершился с ошибкой.' }

flutter analyze
if ($LASTEXITCODE -ne 0) { throw 'flutter analyze обнаружил ошибки. Сборка остановлена для проверки.' }

flutter build apk --release
if ($LASTEXITCODE -ne 0) { throw 'Сборка APK завершилась с ошибкой.' }

$apk = Join-Path $PWD 'build\app\outputs\flutter-apk\app-release.apk'
if (-not (Test-Path $apk)) { throw "Сборка завершилась, но APK не найден: $apk" }
if ((Get-Item $apk).Length -le 0) { throw 'APK существует, но файл пустой.' }

Write-Host "APK создан: $apk" -ForegroundColor Green
Write-Host ("Размер: {0:N2} MB" -f ((Get-Item $apk).Length / 1MB))
Write-Host 'Следующий шаг: установите APK на тестовый телефон и проверьте чат, настройки API и микрофон.' -ForegroundColor Yellow
